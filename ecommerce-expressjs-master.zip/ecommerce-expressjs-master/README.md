# ecommerce-expressjs

# clone project
```bash
$ git clone https://github.com/MuongKimhong/ecommerce-expressjs.git
```

# install packages & start dev server
```bash
$ cd ecommerce-expressjs/API
$ npm install
$ npm start dev

$ cd ../client
$ npm install
$ npm run serve
```

# Vuejs application
```
localhost:8080
```
