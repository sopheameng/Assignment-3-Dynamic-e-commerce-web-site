<template>
    <div>
        <v-app-bar
            color="white"
            class="px-5"
            app
            elevation="4"
        >
            <v-toolbar-title>
                <router-link to="/" id="navbar-logo">AwesomeShop</router-link>
            </v-toolbar-title>

            <v-spacer></v-spacer>

            <v-toolbar-title class="mr-4" v-show="loggedIn">${{userMoney}}</v-toolbar-title>

            <router-link to="/logout" id="logout" v-show="loggedIn">
                <v-btn class="mr-4">Logout</v-btn>
            </router-link>

            
            
            <v-btn class="mr-4" @click="cartItemsDialog = true">
                <v-badge color="green" :value="cartCount" :content="cartCount">
                    cart
                </v-badge>
            </v-btn>
            
                 
            <v-btn v-show="!loggedIn" @click="loginDialog = true">Join</v-btn>

                  
        </v-app-bar>

        <v-dialog v-model="loginDialog" v-show="!loggedIn" class="p-5" width="unset" height="unset" flat>
            <Login />
        </v-dialog>

        <v-dialog v-model="cartItemsDialog" class="p-5" width="unset" height="unset" flat>
            <CartItems @update:boolean="booleanUpdate" @showlogin:boolean="showLogin"/>
        </v-dialog>
    </div> 
</template>

<script>
import { mapGetters, mapState } from "vuex";
import Login from "../views/Login.vue";
import CartItems from "./CartItems.vue";
export default {
    name: "Navbar",
    components: {
        Login,
        CartItems,
    },
    props: [
        "loginDialog",
    ],
    computed: {
        ...mapGetters({
        loggedIn: "loggedIn",
        }),
        ...mapState(["cartCount", "cartItems", "userMoney"])
    },
    data() {
        return {
            cartItemsDialog: false,
            totalPrice: 0,
        }
    },
    methods: {
        booleanUpdate(value) {
            this.cartItemsDialog = value;
        },
        showLogin(value) {
            this.loginDialog = value;
        }
    }
}
</script>

<style scoped>
#navbar-logo {
    text-decoration: none;
    color: black;
}
#logout {
    text-decoration: none;
    color: black
}
#login {
    text-decoration: none;
    color: black
}
.navbar {
    position: sticky;
  top: 0;
  z-index: 999;
}
</style>