<template>
  <div>
    <v-card class="mx-auto pa-5" width="700" max-height="500">
      <v-row>
        <v-col cols="4" class="mx-auto">
          <h4>Name</h4>
        </v-col>
        <v-col cols="5" class="mx-auto">
          <h4>Description</h4>
        </v-col>
        <v-col cols="3" class="mx-auto">
          <h4>Price</h4>
        </v-col>
      </v-row>
      <div v-for="(item, i) in cartItems" :key="i">
        <v-row>
          <v-col cols="4" class="mx-auto">
            <h4>{{ item.name }}</h4>
          </v-col>
          <v-col cols="5" class="mx-auto">
            <h4>{{ item.description }}</h4>
          </v-col>
          <v-col cols="3" class="mx-auto">
            <h4>${{ item.price }}</h4>
          </v-col>
        </v-row>
      </div>
      <v-row>
        <v-col cols="4" class="mx-auto">
          <h4></h4>
        </v-col>
        <v-col cols="5" class="mx-auto">
          <h4></h4>
        </v-col>
        <v-col cols="3" class="mx-auto">
          <h4>${{ totalPrice }}</h4>
        </v-col>
      </v-row>
      <v-card-actions>
        <v-btn @click="cartItemsDialogEvent">
          Close
        </v-btn>
        <v-btn @click="clearCartItem">Delete all</v-btn>
        <v-spacer></v-spacer>
        <v-btn color="success" @click="buy()">Buy</v-btn>
      </v-card-actions>
    </v-card>
  </div>
</template>

<script>
import { mapState, mapGetters } from "vuex";
import store from "../store/index.js";
const axios = require("axios");
export default {
  name: "CartItems",
  computed: {
    ...mapState(["cartItems", "totalPrice", "products", "userMoney"]),
    ...mapGetters({
      loggedIn: "loggedIn",
    }),
  },
  data() {
    return {
      cartItemsDialog: false,
    };
  },
  methods: {
    cartItemsDialogEvent() {
      this.$emit("update:boolean", false);
    },
    clearCartItem() {
      store.commit("clearCartItem");
      this.$emit("update:boolean", false);
    },
    buy() {
      if (this.loggedIn) {
        for (var i = 0; i < this.cartItems.length; i++) {
          if (this.cartItems[i].quantity <= 0) {
            for (var j = 0; j < this.products.length; j++) {
              if (this.cartItems[i]._id == this.products[j]._id) {
                this.products.splice(j, 1);
              }
            }
          }

          axios
            .patch(
              `http://localhost:3000/products/${this.cartItems[i]._id}/update-product-info`,
              {
                quantity: this.cartItems[i].quantity - 1,
              }
            )
            .then(() => {
              this.clearCartItem();
            })
            .catch((err) => {
              console.log(err);
            });
        }
        store.commit("updateUserMoney", this.userMoney - this.totalPrice);
        console.log(this.userMoney);
      } else {
        this.$emit("showlogin:boolean", true);
      }
    },
  },
};
</script>

<style scoped></style>
