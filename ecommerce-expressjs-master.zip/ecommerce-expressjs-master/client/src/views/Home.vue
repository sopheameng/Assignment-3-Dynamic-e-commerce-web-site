<template>
  <div class="home">
    <Navbar :loginDialog="loginDialog" />
    <div class="grey lighten-5 py-5 mt-5">
      <h1 class="text-center shop-your-designer pt-5">
        Shop your designer dresses
      </h1>
      <h3 class="text-center ready-to-wear pb-5">
        Ready to wear dereses tailored for you from online. Hurry up while stack
        lasts
      </h3>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field
          solo
          label="Search your product from here"
          class="mx-auto"
          clearable
        ></v-text-field>
      </v-col>
    </div>

    <v-container class="mt-5">
      <v-row justify="space-around">
        <v-col cols="6" md="4">
          <v-card class="pa-2 pink lighten-4" outlined>
            <h2 class="white--text">Coupon Saving</h2>
            <h5 class="white--text">Up to 60% off everyday essential</h5>
            <v-btn class="mt-5">Shop Coupon</v-btn>
          </v-card>
        </v-col>

        <v-col cols="6" md="4">
          <v-card class="pa-2 orange lighten-2" outlined>
            <h2 class="white--text">Free Delivery</h2>
            <h5 class="white--text">With selected items</h5>
            <v-btn class="mt-5">Deliver Now</v-btn>
          </v-card>
        </v-col>

        <v-col cols="6" md="4">
          <v-card class="pa-2 deep-purple lighten-2" outlined>
            <h2 class="white--text">Gift Voucher</h2>
            <h5 class="white--text">With personal care iterms</h5>
            <v-btn class=" mt-4">Gift Now</v-btn>
          </v-card>
        </v-col>
      </v-row>
    </v-container>

    <v-container>
      <v-row>
        <v-col cols="2" md="2">
          <v-list dense>
            <v-list-item-group color="primary" v-model="selectedItem">
              <v-list-item
                v-for="(item, i) in listItems"
                :key="i"
                @click="displayProduct(item)"
              >
                <v-list-item-content>
                  <v-list-item-title class="pa-3">
                    <h2 v-text="item"></h2>
                  </v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </v-list-item-group>
          </v-list>
        </v-col>

        <v-col cols="10" md="10">
          <div v-show="showProductList">
            <v-flex d-flex>
              <v-layout wrap>
                <v-flex md3 v-for="(product, i) in productList" :key="i">
                  <router-link
                    :to="{
                      name: 'ProductDetail',
                      query: {
                        id: product._id,
                        category: product.category,
                        description: product.description,
                        discountPercent: product.discountPercent,
                        price: product.price,
                      },
                    }"
                  >
                    <v-card class="mx-5 my-4" height="260">
                      <!-- img -->
                      <v-row>
                        <v-col cols="8" class="mr-0 pr-0">
                          <v-img
                            v-if="product.category == 'Clothes'"
                            src="../assets/clothes.png"
                            class="mr-0 pr-0"
                            max-height="150"
                            max-width="250"
                          ></v-img>
                          <v-img
                            v-if="product.category == 'Electronics'"
                            src="../assets/icon_laptop.png"
                            class="mr-0 pr-0"
                            max-height="150"
                            max-width="250"
                          ></v-img>
                          <v-img
                            v-if="product.category == 'Hand bags'"
                            src="../assets/icon_bag-front-view.png"
                            class="mr-0 pr-0"
                            max-height="150"
                            max-width="250"
                          ></v-img>
                          <v-img
                            v-if="product.category == 'Wallets'"
                            src="../assets/icon_wallet.png"
                            class="mr-0 pr-0"
                            max-height="150"
                            max-width="250"
                          ></v-img>
                        </v-col>
                        <v-col cols="4" class="ml-0 pl-0">
                          <v-chip color="orange lighten-1"
                            >{{ product.discountPercent }}%</v-chip
                          >
                        </v-col>
                      </v-row>
                      <!-- end img -->
                      <v-card-text class="ml-3 mb-0 pb-0">{{
                        product.description
                      }}</v-card-text>
                      <v-row>
                        <v-col cols="5">
                          <v-card-text class="mr-5 green--text"
                            >${{ product.price }}</v-card-text
                          >
                        </v-col>
                        <v-col cols="7">
                          <v-btn
                            small
                            class="mt-4 ml-5"
                            @click="addItemToCart(product)"
                            >cart</v-btn
                          >
                        </v-col>
                      </v-row>
                    </v-card>
                  </router-link>
                </v-flex>
              </v-layout>
            </v-flex>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
const axios = require("axios");
const moment = require("moment");
import store from "../store/index.js";
import { mapState } from "vuex";
import Navbar from "../components/Navbar";
export default {
  name: "Home",
  components: {
    Navbar,
  },
  computed: {
    ...mapState(["products", "cartCount", "cartItems", "totalPrice"]),
  },
  created() {
    this.getAllProducts();
  },
  data() {
    return {
      product: null,
      loginDialog: false,
      selectedItem: 0,
      listItems: ["Electronics", "Hand bags", "Wallets", "Clothes"],
      productList: [],
      showProductList: true,
      showProductDetail: false,
    };
  },
  methods: {
    getAllProducts() {
      axios
        .get("http://127.0.0.1:3000/products")
        .then((response) => {
          store.commit("getProducts", response["data"]);

          // format date
          for (var i = 0; i < this.$store.state.products.length; i++) {
            this.$store.state.products[i].postDate = moment(
              this.$store.state.products[i].postDate
            ).format("MMM Do YY");
          }

          for (var j = 0; j < this.products.length; j++) {
            if (this.products[j].category == "Electronics") {
              this.productList.push(this.products[j]);
            }
          }
        })
        .catch((error) => {
          console.log(error);
        });
    },

    displayProduct(item) {
      this.productList = [];
      for (var i = 0; i < this.products.length; i++) {
        if (this.products[i].category == item) {
          this.productList.push(this.products[i]);
        }
      }
    },

    addItemToCart(product) {
      store.commit("cartCountIncrement");
      this.cartItems.push(product);
      store.commit("getTotalPrice", parseInt(product.price));
    },

    goToProductDetail(product) {
      this.showProductList = false;
      this.showProductDetail = true;
      this.product = product;
    },

    showLogin() {
      this.loginDialog = true;
    },
  },
};
</script>

<style scoped>
.shop-your-designer {
  font-size: 60px;
}
</style>
