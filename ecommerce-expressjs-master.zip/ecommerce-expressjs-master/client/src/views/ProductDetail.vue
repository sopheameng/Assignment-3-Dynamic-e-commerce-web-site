<template>
  <div class="product detail">
    <Navbar :loginDialog="loginDialog" />
    <div class="grey lighten-5 py-5 mt-5">
      <h1 class="text-center shop-your-designer pt-5">
        Shop your designer dresses
      </h1>
      <h3 class="text-center ready-to-wear pb-5">
        Ready to wear dereses tailored for you from online. Hurry up while stack
        lasts
      </h3>
      <v-col cols="12" sm="6" class="mx-auto">
        <v-text-field
          solo
          label="Search your product from here"
          class="mx-auto"
          clearable
        ></v-text-field>
      </v-col>
    </div>

    <v-container class="mt-5">
      <v-row justify="space-around">
        <v-col cols="6" md="4">
          <v-card class="pa-2 pink lighten-4" outlined>
            <h2 class="white--text">Coupon Saving</h2>
            <h5 class="white--text">Up to 60% off everyday essential</h5>
            <v-btn class="mt-5">Shop Coupon</v-btn>
          </v-card>
        </v-col>

        <v-col cols="6" md="4">
          <v-card class="pa-2 orange lighten-2" outlined>
            <h2 class="white--text">Free Delivery</h2>
            <h5 class="white--text">With selected items</h5>
            <v-btn class="mt-5">Deliver Now</v-btn>
          </v-card>
        </v-col>

        <v-col cols="6" md="4">
          <v-card class="pa-2 deep-purple lighten-2" outlined>
            <h2 class="white--text">Gift Voucher</h2>
            <h5 class="white--text">With personal care iterms</h5>
            <v-btn class=" mt-4">Gift Now</v-btn>
          </v-card>
        </v-col>
      </v-row>
    </v-container>

    <v-container>
      <v-row>
        <v-col cols="2" md="2">
          <v-list dense>
            <v-list-item-group color="primary" v-model="selectedItem">
              <v-list-item
                v-for="(item, i) in listItems"
                :key="i"
              >
                <v-list-item-content>
                  <v-list-item-title class="pa-3">
                    <h2 v-text="item"></h2>
                  </v-list-item-title>
                </v-list-item-content>
              </v-list-item>
            </v-list-item-group>
          </v-list>
        </v-col>

        <v-col cols="10" md="10">
          <div>
            <v-card max-height="10000">
              <div>
                <v-row>
                  <v-col cols="5">
                    <v-img
                      v-if="product.category == 'Clothes'"
                      src="../assets/clothes.png"
                      class="pa-5 ma-5"
                      max-height="300"
                      max-width="300"
                    ></v-img>
                    <v-img
                      v-if="product.category == 'Electronics'"
                      src="../assets/icon_laptop.png"
                      class="pa-5 ma-5"
                      max-height="300"
                    ></v-img>
                    <v-img
                      v-if="product.category == 'Hand bags'"
                      src="../assets/icon_bag-front-view.png"
                      class="pa-5 ma-5"
                      max-height="300"
                      max-width="300"
                    ></v-img>
                    <v-img
                      v-if="product.category == 'Wallet'"
                      src="../assets/icon_wallet.png"
                      class="ma-5 pa-5"
                      max-height="300"
                    ></v-img>
                  </v-col>
                  <v-divider vertical></v-divider>
                  <v-col cols="6" class="pa-5">
                    <h2 class="my-5">{{ product.name }}</h2>
                    <h3 class="my-5">{{ product.price }}</h3>
                    <h3 class="my-5">{{ product.description }}</h3>

                    <v-btn @click="addItemToCart(product)" class="mt-5"
                      >cart</v-btn
                    >
                  </v-col>
                </v-row>
              </div>
              <div class="ma-5">
                <h1>Comments</h1>
                <div class="my-4" v-for="(comment, i) in userComments" :key="i">
                  <v-card class="pa-5">
                    <h3>{{ comment.commentOwnerName }}</h3>
                    <h4>{{ comment.commentContent }}</h4>
                  </v-card>
                </div>
                <div>
                  <v-textarea
                    outlined
                    name="comment"
                    label="Comment"
                    v-model="commentContent"
                  ></v-textarea>
                  <v-btn class="success mb-5" @click="commentFunction(product)"
                    >send</v-btn
                  >
                  <v-btn class="mb-5 ml-5">back</v-btn>
                </div>
              </div>
            </v-card>
          </div>
        </v-col>
      </v-row>
    </v-container>
  </div>
</template>

<script>
import store from "../store/index.js";
import { mapState, mapGetters } from "vuex";
import Navbar from "../components/Navbar.vue";
const axios = require("axios");
export default {
  name: "ProductDetail",
  components: {
    Navbar,
  },
  computed: {
    ...mapState([
      "products",
      "cartCount",
      "cartItems",
      "totalPrice",
      "userComments",
      "userInfo",
    ]),
    ...mapGetters({
      loggedIn: "loggedIn",
    }),
  },
  data() {
    return {
      product: null,
      loginDialog: false,
      commentContent: null,
      selectedItem: 0,
      listItems: ["Electronics", "Hand bags", "Wallet", "Clothes"],
    };
  },
  created() {
    this.product = this.$route.query;
    this.getAllComments();
  },
  methods: {
    addItemToCart(product) {
      store.commit("cartCountIncrement");
      this.cartItems.push(product);
      store.commit("getTotalPrice", parseInt(product.price));
    },

    getAllComments() {
      axios
        .get(`http://localhost:3000/comments/productComments/${this.product.id}`)
        .then((response) => {
          console.log(response["data"]);
          store.commit("clearComments");
          store.commit("getComments", response['data'])
        })
        .catch((error) => {
          console.log(error);
        });
    },

    commentFunction(product) {
      if (this.loggedIn) {
        axios
          .post(`http://localhost:3000/comments`, {
            commentOwnerName: this.userInfo.username,
            commentOwnerID: this.userInfo._id,
            commentContent: this.commentContent,
            productID: product.id,
          })
          .then((response) => {
            this.userComments.push(response["data"]);
          })
          .catch((err) => {
            console.log(err);
          });
      } else {
        this.$emit("showLogin:boolean", true);
      }
    },
  },
};
</script>

<style scoped></style>
