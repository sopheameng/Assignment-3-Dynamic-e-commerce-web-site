<template>
    <div>
        <v-card v-show="showLogin" class="mx-auto px-5 py-5" max-width="500" elevation="9">
            <h1 class="text-center mt-5">Welcome to Awesome Shop</h1>
            <h5 class="text-center mt-3">Enter your email address and password to continue</h5>

            <v-card class="mx-auto px-3 py-3 mt-5" color="red accent-4" max-width="300" flat v-if="errorMessageBox">
                <h4 class="text-center white--text">{{ errorMessage }}</h4>
            </v-card>
            
            <v-card class="mx-auto px-3 py-3 mt-5" color="green accent-4" max-width="300" flat v-if="successMessageBox">
                <h4 class="text-center white--text">{{ successMessage }}</h4>
            </v-card>

            <v-form class="mt-5" v-show="showLogin">
                <v-text-field
                    v-model="email"
                    label="Email Address"
                    type="email"
                    required
                ></v-text-field>

                <v-text-field
                    v-model="password"
                    label="Password"
                    type="password"
                    required
                ></v-text-field>
                
                <v-btn color="primary col-12 mb-5" @click="login()">Login</v-btn>
            </v-form>
            <h5 class="text-center mt-5">Don't have an account? <a @click="showRegisterForm">Register</a></h5>
        </v-card> 

        <!-- register card -->
        <v-card v-show="showRegister" class="mx-auto px-5 py-5" max-width="500" elevation="9">
            <h1 class="text-center mt-5">Welcome to Awesome Shop</h1>
            <h5 class="text-center mt-3">Create your free account now</h5>
            
            <v-card class="mx-auto px-3 py-3 mt-5" color="red accent-4" max-width="300" flat v-if="errorMessageBox">
                <h4 class="text-center white--text">{{ errorMessage }}</h4>
            </v-card>

            <v-form class="mt-5">
                <v-text-field v-model="email" label="Email Address" type="email" required></v-text-field>
                <v-text-field v-model="username" label="Username" type="text" required></v-text-field>
                <v-text-field v-model="password" label="Password" type="password" required></v-text-field>
                <v-text-field v-model="confirmPassword" label="Confirm Password" type="password" required></v-text-field>
                <v-btn color="primary col-12 mb-5" @click="register()">Register</v-btn>
            </v-form>
            <h5 class="text-center mt-5">Already have an account? <a @click="showLoginForm">Login</a></h5>
        </v-card> 
    </div> 
</template>

<script>
const axios = require('axios')
export default {
    name: "Login", 
    data() {
        return {
            email: null,
            username: null,
            password: null,
            confirmPassword: null,
            errorMessage: null,
            errorMessageBox: false,
            successMessage: null,
            successMessageBox: false,

            showLogin: true,
            showRegister: false,
        }
    },

    methods: {
        login() {
            this.$store.dispatch("userLogin", {
                email: this.email,
                password: this.password,
            })
            .then(() => {
                location.reload();
            })
            .catch((error) => {
                this.errorMessageBox = true;
                this.errorMessage = "Email or password is incorrect";
                setTimeout(() => (this.errorMessageBox = false), 3500);
                console.log(error.response.data);
            })
        },

        register() {
            if (this.password != this.confirmPassword) {
                this.errorMessageBox = true;
                this.errorMessage = "Two password don't match";
            }
            else {
                axios.post("http://127.0.0.1:3000/users", {
                    email: this.email,
                    username: this.username,
                    password: this.password,
                })
                .then(() => {
                    this.successMessageBox = true;
                    this.successMessage = "Account created successfully";
                    this.showRegister = false;
                    this.showLogin = true;
                })
                .catch((error) => {
                    this.errorMessageBox = true;
                    this.errorMessage = error.response.data.message;
                })
            }
        },

        showRegisterForm() {
            this.showLogin = false;
            this.showRegister = true;
        },

        showLoginForm() {
            this.showRegister = false;
            this.showLogin = true;
        }
    }
}
</script>


<style scoped>

</style>