<template>
    <div>
        <v-card class="mx-auto px-5 py-5" max-width="500" elevation="9">
            <h1 class="text-center mt-5">Welcome to Awesome Shop</h1>
            <h5 class="text-center mt-3">Enter your email address and password to continue</h5>
            <h5 class="text-center mt-3">You must be admin to access to the admin panel</h5>
            <v-card class="mx-auto px-3 py-3 mt-5" color="red accent-4" max-width="300" flat v-if="errorMessageBox">
                <h4 class="text-center white--text">{{ errorMessage }}</h4>
            </v-card>
            <v-form class="mt-5">
                <v-text-field
                    v-model="email"
                    label="Email Address"
                    type="email"
                    required
                ></v-text-field>

                <v-text-field
                    v-model="password"
                    label="Password"
                    type="password"
                    required
                ></v-text-field>
                
                <v-btn color="primary col-12 mb-5" @click="adminLogin()">Login</v-btn>
            </v-form>
        </v-card> 
    </div> 
</template>


<script>
export default {
    name: "AdminLogin", 
    data () {
        return {
            email: null,
            password: null,
            errorMessage: null,
            errorMessageBox: false,
        }
    },

    methods: {
        adminLogin() {
            this.$store.dispatch("adminLogin", {
                email: this.email,
                password: this.password,
            })
            .then(() => {
                this.$router.push({name: "AdminPanel"})
            })
            .catch((error) => {
                this.errorMessageBox = true;
                this.errorMessage = error.response.data.errorMessage;
                setTimeout(() => (this.errorMessageBox = false), 3500);
                console.log(error.response.data);
            })
        },
    }
}
</script>