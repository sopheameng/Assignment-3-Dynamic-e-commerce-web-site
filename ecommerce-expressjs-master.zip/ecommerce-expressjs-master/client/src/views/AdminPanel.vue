<template>
  <div class="home">
    <Navbar/>
      <v-card class="mx-auto p-5" max-width="800">
        <v-tabs center-active centered v-model="tab">
            <v-tab href="#tab-1">Products</v-tab>
            <v-tab>User</v-tab>
            <v-tab>Purchased order</v-tab>
            <v-tab>History</v-tab>
        </v-tabs>

        <v-tabs-items v-model="tab">
            <v-tab-item :value="'tab-1'">
                <v-card flat class="p-5 m-5">
                    <v-data-table :headers="headers" :items="$store.state.products" class="elevation-1">
                        <template v-slot:top>
                            <v-toolbar
                                flat
                                class="mt-5"
                            >
                                <v-toolbar-title>All products in Stock</v-toolbar-title>

                                <v-divider class="mx-4" inset vertical></v-divider>

                                <v-spacer></v-spacer>

                                <v-dialog v-model="addDialog" max-width="500px">

                                    <template v-slot:activator="{ on, attrs }">
                                        <v-btn color="success" class="mb-2" v-bind="attrs" v-on="on">Add Product</v-btn>
                                    </template>

                                    <v-card>
                                        <v-card-title>
                                            <span class="headline">Add new product</span>
                                        </v-card-title>

                                        <v-card-text>
                                            <v-container>
                                                <v-text-field v-model="addedItem.name" label="Product Name"></v-text-field>
                                                <v-text-field v-model="addedItem.quantity" label="Qty"></v-text-field>
                                                <v-textarea  v-model="addedItem.description" label="Description"></v-textarea>
                                                <v-text-field v-model="addedItem.price" label="Price"></v-text-field>
                                                <v-select :items="productCategories" v-model="addedItem.category" label="Category"></v-select>
                                            </v-container>
                                        </v-card-text>
                                        
                                        <!-- save added product button -->
                                        <v-card-actions>
                                            <v-spacer></v-spacer>
                                            <v-btn color="green darken-1" text @click="addDialog = false">Cancel</v-btn>
                                            <v-btn color="green darken-1" text @click="addProduct">Save</v-btn>
                                        </v-card-actions>
                                        <!-- end save added product button -->

                                    </v-card>
                                </v-dialog>

                            </v-toolbar>
                        </template>

                        <template v-slot:[`item.actions`]="{ item }">
                            <!-- Update Product Info Dialog -->
                            <v-dialog v-model="updateDialog" max-width="500px">
                                <v-card>
                                    <v-card-title class="headline">Update Product Info</v-card-title>

                                    <v-card-text>
                                        <v-container>
                                            <v-text-field v-model="updatedItem.name" label="Product Name"></v-text-field>
                                            <v-text-field v-model="updatedItem.quantity" label="Qty"></v-text-field>
                                            <v-textarea  v-model="updatedItem.description" label="Description"></v-textarea>
                                            <v-text-field v-model="updatedItem.price" label="Price"></v-text-field>
                                            <v-select :items="productCategories" v-model="updatedItem.category" label="Category"></v-select>
                                        </v-container>
                                    </v-card-text>

                                    <v-card-actions>
                                        <v-spacer></v-spacer>
                                        <v-btn color="blue darken-1" text @click="updateDialog = false;">Cancel</v-btn>
                                        <v-btn color="blue darken-1" text @click="updateProductInfo()">OK</v-btn>
                                    </v-card-actions>
                                </v-card>
                            </v-dialog>
                            <!-- End update product info dialog -->

                            <!-- Delete Product Dialog -->
                            <v-dialog v-model="deleteDialog" max-width="500px">
                                <v-card>
                                    <v-card-title class="headline">Are you sure you want to delete this?</v-card-title>

                                    <v-card-actions>
                                        <v-spacer></v-spacer>
                                        <v-btn color="blue darken-1" text @click="deleteDialog = false;">Cancel</v-btn>
                                        <v-btn color="blue darken-1" text @click="deleteProduct()">Delete</v-btn>
                                    </v-card-actions>
                                </v-card>
                            </v-dialog>
                            <!-- End delete product dialog -->

                            <v-icon small class="mr-2" @click="openUpdateProductDialog(item._id)">mdi-pencil</v-icon>
                            <v-icon small @click="openDeleteProductDialog(item._id)">mdi-delete</v-icon>
                        </template>

                    </v-data-table>
                </v-card>
            </v-tab-item>
        </v-tabs-items>
      </v-card>
  </div>
</template>

<script>
import Navbar from "../components/Navbar";
const axios = require('axios');
const moment = require('moment');
import store from '../store/index.js';
import {mapState} from 'vuex';
export default {
  name: "AdminPanel",
  components: {
    Navbar,
  },

    data () {
        return {
            tab: null,
            addDialog: false,
            updateDialog: false,
            updateProductID: null,
            deleteDialog: false,
            deleteProductID : null,
            headers: [
                { text: 'Name', value: 'name'},
                { text: 'Qty', value: 'quantity' },
                { text: 'Description', value: 'description' },
                { text: 'Instock at', value: 'postDate' },
                { text: 'Category', value: 'category' },
                { text: 'Actions', value: 'actions'},
            ],
            productCategories: ['Hand bags', 'Electronics', 'Clothes', 'Wallets'],
            updatedItem: {
                name: '',
                description: '',
                category: '',
                quantity: '',
                price: '',
            },
            addedItem: {
                name: '',
                description: '',
                category: '',
                quantity: '',
                price: '',
            },
        }
    },

    computed: {
        ...mapState(["products"])
    },

    created () {
      this.getAllProducts();
    },

    methods: {
        // Get all products
        getAllProducts () {
            axios.get('http://127.0.0.1:3000/products')
            .then((response) => {
                store.commit("getProducts", response['data'])

                // format date
                for (var i=0; i<this.$store.state.products.length; i++) {
                    this.$store.state.products[i].postDate = moment(this.$store.state.products[i].postDate).format("MMM Do YY");
                }
            })
            .catch((error) => {
                console.log(error);
            })
        },

        // Added product
        addProduct() {
            axios.post('http://127.0.0.1:3000/products' , {
                name: this.addedItem.name,
                description: this.addedItem.description,
                category: this.addedItem.category,
                quantity: parseInt(this.addedItem.quantity),
                price: this.addedItem.price,
            })
            .then((response) => {
                this.products.push(response.data);  
                // update date format
                this.products[this.products.length - 1].postDate = moment(this.products[this.products.length - 1].postDate).format("MMM Do YY");
                this.addDialog = false;  

                // clear text fields
                for (const property in this.addedItem) {
                    this.addedItem[property] = null; 
                }
            })
            .catch((error) => {
                console.log(error);
            })
        },

        updateProductInfo() {
            if (this.updateDialog) {
                axios.patch(`http://127.0.0.1:3000/products/${this.updateProductID}/update-product-info`, {
                    name: this.updatedItem.name,
                    description: this.updatedItem.description,
                    category: this.updatedItem.category,
                    quantity: this.updatedItem.quantity,
                    price: this.updatedItem.price,
                })
                .then((response) => {
                    // update products elements
                    for (var i=0; i<this.products.length; i++) {
                        if (this.products[i]._id === this.updateProductID) {
                            this.products[i].name = response.data.name;
                            this.products[i].description = response.data.description;
                            this.products[i].category = response.data.category;
                            this.products[i].quantity = response.data.quantity;
                            this.products[i].price = response.data.price;
                            this.updateDialog = false;
                        }
                    }
                })
                .catch ((error) => {
                    console.log(error)
                })
            }
            
        },

        openUpdateProductDialog(id) {
            console.log(id)
            this.updateProductID = id;
            this.updateDialog = true;
            axios.get(`http://127.0.0.1:3000/products/${id}`)
            .then((response) => {  
                this.updatedItem.name = response.data.name;
                this.updatedItem.description = response.data.description;
                this.updatedItem.category = response.data.category;
                this.updatedItem.quantity = response.data.quantity;
                this.updatedItem.price = response.data.price;
            })
            .catch((error) => {
                console.log(error)
            })
        },

        openDeleteProductDialog(id) {
            console.log(id);
            this.deleteProductID = id;
            this.deleteDialog = true;
        },

        deleteProduct() {
            if (this.deleteDialog) {
                axios.delete(`http://127.0.0.1:3000/products/${this.deleteProductID}/delete`, {
                })
                .then((response) => {
                    console.log(response);
                    this.deleteDialog = false;
                    for (var i=0; i<this.products.length; i++) {
                        if (this.products[i]._id === this.deleteProductID) {
                            console.log(this.products[i])
                            this.products.splice(i, 1);
                        }
                    }
                })
                .catch((error) => {
                    console.log(error)
                })
            }
        },
    },
};

</script>
