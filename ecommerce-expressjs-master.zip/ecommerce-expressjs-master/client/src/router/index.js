import Vue from "vue";
import VueRouter from "vue-router";
import Home from "../views/Home.vue";
import Login from "../views/Login.vue";
import AdminLogin from "../views/AdminLogin.vue";
import AdminPanel from "../views/AdminPanel.vue";
import Logout from "../views/Logout.vue";
import ProductDetail from "../views/ProductDetail.vue";

import store from "../store/index";

Vue.use(VueRouter);

const routes = [
  {
    path: "/",
    name: "Home",
    component: Home
  },
  {
    path: "/product/",
    name: "ProductDetail",
    component: ProductDetail,
  },
  {
    path: "/admin",
    name: "AdminPanel",
    component: AdminPanel,
    beforeEnter: (to, from, next) => {
      if (!store.getters.loggedIn) next("/admin/login");
      else if (store.getters.loggedIn) {
        if (!store.getters.isAdminUser) next("/logout")
        else next();
      }
      else next();
    }
  },
  {
    path: "/login",
    name: "Login",
    component: Login
  },
  {
    path: "/logout",
    name: "Logout",
    component: Logout,
    beforeEnter: (to, from, next) => {
      if (!store.getters.loggedIn) next("/login");
      else next();
    }
  },
  {
    path: "/admin/login",
    name: "AdminLogin",
    component: AdminLogin,
    beforeEnter: (to, from, next) => {
      if (store.getters.loggedIn) next("/logout")
      else next();
    }
  },
  {
    path: "/about",
    name: "About",
    // route level code-splitting
    // this generates a separate chunk (about.[hash].js) for this route
    // which is lazy-loaded when the route is visited.
    component: () =>
      import(/* webpackChunkName: "about" */ "../views/About.vue")
  }
];

const router = new VueRouter({
  routes
});

export default router;
