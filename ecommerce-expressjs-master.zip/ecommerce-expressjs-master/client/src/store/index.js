import Vue from "vue";
import Vuex from "vuex";
import VuexPersist from "vuex-persist";

const axios = require('axios');

Vue.use(Vuex);
const vuexLocalStorage = new VuexPersist({
  key: "vuex", // The key to store the state on in the storage provider.
  storage: window.localStorage, // or window.sessionStorage or localForage
});

export default new Vuex.Store({
  plugins: [vuexLocalStorage.plugin],

  state: {
    isLoggedIn: false,
    userInfo: {},
    products: [],
    dialog: {loginDialog: false, registerDialog: false},
    cartCount: 0,
    cartItems: [],
    totalPrice: 0,
    userMoney: 200000,
    userComments: [],
  },

  mutations: {
    updateStorage(state, {access, userInfo}) {
      state.isLoggedIn = access;
      state.userInfo = userInfo;
    },
    destroyToken(state) {
      state.isLoggedIn = false;
      state.userInfo = {};
    },
    getProducts(state, productItems) {
      state.products = productItems;
    },
    getComments(state, comments) {
      state.userComments = comments;
    },
    clearComments(state) {
      state.userComments = [];
    },
    openLoginDialog(state) { state.dialog.loginDialog = true; },
    closeLoginDialog(state) { state.dialog.loginDialog = false; },
    openRegisterDialog(state) { state.dialog.registerDialog = true; },
    closeRegisterDialog(state) { state.dialog.registerDialog = false; },

    cartCountIncrement(state) {
      state.cartCount++;
    },

    clearCartItem(state) {
      state.cartItems = [];
      state.cartCount = 0;
      state.totalPrice = 0;
    },
    
    getTotalPrice(state, price) {
      state.totalPrice += price;
    },

    updateUserMoney(state, price) {
      state.userMoney = price;
    }
  },

  getters: {
    loggedIn(state) {
      return state.isLoggedIn != false;
    },
    isNormalUser(state) {
      if (state.userInfo.userType == "normal") return true;
    },
    isAdminUser(state) {
      console.log(state.userInfo)
      if (state.userInfo.userType == "admin") return true;
    }
  },

  actions: {
    adminLogin(context, userCredentials) {
      return new Promise((resolve, reject) => {
        axios.post("http://localhost:3000/users/admin/login", {
          email: userCredentials.email,
          password: userCredentials.password,
        })
        .then((response) => {
          console.log(response)
          context.commit("updateStorage", {
            access: true,
            userInfo: response.data,
          });
          resolve();
        })
        .catch((error) => {
          console.log(error);
          reject(error);
        })
      })
    },

    userLogin(context, userCredentials) {
      return new Promise((resolve, reject) => {
        axios.post("http://localhost:3000/users/login", {
          email: userCredentials.email,
          password: userCredentials.password,
        })
          .then((response) => {
            console.log(response)
            context.commit("updateStorage", {
              access: true,
              userInfo: response.data,
            });
            resolve();
          })
          .catch((error) => {
            console.log(error);
            reject(error);
          })
      })
    },

    userLogout(context) {
      if (context.getters.loggedIn) {
        context.commit("destroyToken");
      }
    }
  },

  modules: {}
});
