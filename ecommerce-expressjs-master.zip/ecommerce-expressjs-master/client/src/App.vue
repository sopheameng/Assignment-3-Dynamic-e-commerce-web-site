<template>
  <v-app>
    <div id="content">
      <router-view></router-view>
    </div>
  </v-app>
</template>

<script>

export default {
  name: "App",
  
  data: () => ({
    //
  })
};
</script>

<style>
#content{
  margin-top: 120px;
}
h1, h2, h3, h4, h5, h6, p {
  font-family: 'Lato', sans-serif;
}
</style>
