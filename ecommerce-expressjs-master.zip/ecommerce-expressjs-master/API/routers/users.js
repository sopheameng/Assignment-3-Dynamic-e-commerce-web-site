const express = require('express')
const router = express.Router()
const User = require("../models/users")
const bcrypt = require('bcrypt')

// get all users
router.get('/', async (req, res) => {
    try {
        const users = await User.find();
        res.json(users)
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})

// get one user
router.get('/:id', getUserByID, (req, res) => {
    res.status(200).json(res.user)
})

// register new user
router.post('/', async (req, res) => {
    // query User model with email
    var queryResult = User.find({ 'email': req.body.email })
    queryResult.exec(function (err, users) {
        if (users.length > 0) callback("Exist")
        else callback("Not Exist")
    })

    async function callback(param) {
        if (param == "Exist") {
            res.status(400).json({ message: "user with this email already exist" })
        }
        else if (param == "Not Exist"){
            // hash password
            const hashedPassword = await bcrypt.hash(req.body.password, 10)

            const user = new User({
                email: req.body.email,
                username: req.body.username,
                password: hashedPassword,
            })
            try {
                const newUser = await user.save()
                res.status(200).json({ success: "successfully created user" })
            }
            catch (error) {
                res.status(400).json({ message: error.message })
            }
        }
    }
})


// register new user ( Admin )
router.post('/admin', async (req, res) => {
    // query User model with email
    var queryResult = User.find({ 'email': req.body.email })
    queryResult.exec(function (err, users) {
        if (users.length > 0) callback("Exist")
        else callback("Not Exist")
    })

    async function callback(param) {
        if (param == "Exist") {
            res.status(400).json({ message: "user with this email already exist" })
        }
        else if (param == "Not Exist") {
            // hash password
            const hashedPassword = await bcrypt.hash(req.body.password, 10)

            const user = new User({
                email: req.body.email,
                username: req.body.username,
                userType: req.body.userType,
                password: hashedPassword,
            })
            try {
                const newUser = await user.save()
                res.status(200).json({ success: "successfully created user" })
            }
            catch (error) {
                res.status(400).json({ message: error.message })
            }
        }
    }
})

// log in user
router.post('/login', async (req, res) => {
    // query User model with email
    var queryResult = User.find({ 'email': req.body.email })
    queryResult.exec(async function (err, users) {
        if (users.length > 0) callback("Exist", users[0].password, users[0])
        else callback("Not Exist", "");
    })

    async function callback(data, param, userInfo) {
        if (data == "Exist") {
            try {
                if (await bcrypt.compare(req.body.password, param)) {
                    res.status(200).json(userInfo)
                }
                else {
                    res.status(400).json({ error: true })
                }
            }
            catch (error) {
                res.status(400).json({ error: error.message })
            } 
        }
        else if (data == "Not Exist") {
            res.status(400).json({error: true})
        }
        
    }
    
})

// log in user ( admin )
router.post('/admin/login', async (req, res) => {
    // query User model with email
    var queryResult = User.find({ 'email': req.body.email })
    queryResult.exec(async function (err, users) {
        if (users.length > 0) {
            if (users[0].userType == "admin") callback("Exist", users[0].password, users[0])
            else callback("Exist", "Not admin", "")
        } 
        else callback("Not Exist", "");
    })

    async function callback(data, param, userCredentials) {
        if (data == "Exist") {
            if (param == "Not admin") {
                res.status(400).json({errorMessage: "Not Admin"})
            }
            else {
                try {
                    if (await bcrypt.compare(req.body.password, param)) {
                        res.status(200).json(userCredentials)
                    }
                    else {
                        res.status(400).json({ errorMessage: "Email or password is incorrect" })
                    }
                }
                catch (error) {
                    res.status(400).json({ error: error.message })
                }
            }
            
        }
        else if (data == "Not Exist") {
            res.status(400).json({ errorMessage: "Email or password is incorrect" })
        }

    }

})

// update user info
router.patch('/:id/update-info', getUserByID, async (req, res) => {
    if (req.body.email != null) {
        res.user.email = req.body.email
    }
    if (req.body.username != null) {
        res.user.username = req.body.username
    }
    try {
        const updateUserInfo = await res.user.save()
        res.json(updateUserInfo)
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})

// remove user
router.delete('/:id/delete', getUserByID, async (req, res) => {
    try {
        await res.user.remove()
    }
    catch (error) {
        res.status(400).json({message: error.message})
    }
})


// middleware
async function getUserByID(req, res, next) {
    var user;
    try {
        user = await User.findById(req.params.id)
        if (user == null) {
            return res.status(404).json({message: "Couldn't find user with the id"}) 
        }
    }
    catch (error) {
        return res.status(400).json({message: error.message})
    }
    res.user = user
    next()
}

module.exports = router