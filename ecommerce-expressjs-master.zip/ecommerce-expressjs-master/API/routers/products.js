const express = require('express')
const router = express.Router()
const Product = require("../models/products")

// get all products
router.get('/', async (req, res) => {
    try {
        const products = await Product.find()
        res.json(products)
    }
    catch (error) {res.status(400).json({ message: error.message })}
})

// get one product
router.get('/:id', getProductByID, (req, res) => {
    res.status(200).json(res.product)
})

// create product
router.post('/', async (req, res) => {
    const product = new Product({   
        name: req.body.name,
        category: req.body.category,
        price: req.body.price,
        quantity: req.body.quantity,
        description: req.body.description,
        discount: req.body.discount,
        discountPercent: req.body.discountPercent,
    })
    try {
        const newProduct = await product.save()
        res.status(200).json(product)
    }
    catch (error) {res.status(400).json({message: error.message})}
})

// update product
router.patch('/:id/update-product-info', getProductByID, async (req, res) => {
    var fields = ['name', 'category', 'price', 'description', 'discount', 'discountPercent', 'quantity']

    for (var i=0; i<=fields.length; i++) {
        if (req.body[fields[i]] != null) {
            res.product[fields[i]] = req.body[fields[i]]
        }
    }
    try {
        const updateProductInfo = await res.product.save()
        res.json(updateProductInfo)
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})

// delete product
router.delete('/:id/delete', getProductByID, async (req, res) => {
    try {
        await res.product.remove()
        res.status(200).json({message: "Product is deleted"})
    }
    catch (error) {
        res.status(400).json({ message: error.message })
    }
})

// middleware
async function getProductByID(req, res, next) {
    var product;
    try {
        product = await Product.findById(req.params.id)
        if (product == null) {
            return res.status(404).json({ message: "Couldn't find product with the id" })
        }
    }
    catch (error) {
        return res.status(400).json({ message: error.message })
    }
    res.product = product
    next()
}

module.exports = router