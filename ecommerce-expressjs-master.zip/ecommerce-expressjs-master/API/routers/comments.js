const express = require('express')
const router = express.Router()
const Comment = require("../models/comments")

// get all products
router.get('/', async (req, res) => {
    try {
        const comments = await Comment.find()
        res.json(comments)
    }
    catch (error) { res.status(400).json({ message: error.message }) }
})

// get one product
router.get('/:id', getCommentByID, (req, res) => {
    res.status(200).json(res.comment)
})

// get all comments that belong to each product
router.get('/productComments/:productID', async (req, res) => {
    try {
        const comments = await Comment.find({'productID': req.params.productID});
        res.json(comments);
    }
    catch(error) {
        console.log(error)
    }
})

// create product
router.post('/', async (req, res) => {
    const comment = new Comment({
        commentOwnerName: req.body.commentOwnerName,
        commentOwnerID: req.body.commentOwnerID,
        commentContent: req.body.commentContent,
        productID: req.body.productID,
    })
    try {
        const newComment = await comment.save()
        res.status(200).json(comment)
    }
    catch (error) { res.status(400).json({ message: error.message }) }
})

// update product
// router.patch('/:id/update-product-info', getProductByID, async (req, res) => {
//     var fields = ['name', 'category', 'price', 'description', 'discount', 'discountPercent', 'quantity']

//     for (var i = 0; i <= fields.length; i++) {
//         if (req.body[fields[i]] != null) {
//             res.product[fields[i]] = req.body[fields[i]]
//         }
//     }
//     try {
//         const updateProductInfo = await res.product.save()
//         res.json(updateProductInfo)
//     }
//     catch (error) {
//         res.status(400).json({ message: error.message })
//     }
// })

// delete product
// router.delete('/:id/delete', getProductByID, async (req, res) => {
//     try {
//         await res.product.remove()
//         res.status(200).json({ message: "Product is deleted" })
//     }
//     catch (error) {
//         res.status(400).json({ message: error.message })
//     }
// })

// middleware
async function getCommentByID(req, res, next) {
    var comment;
    try {
        comment = await Comment.findById(req.params.id)
        if (comment == null) {
            return res.status(404).json({ message: "Couldn't find comment with the id" })
        }
    }
    catch (error) {
        return res.status(400).json({ message: error.message })
    }
    res.comment = comment
    next()
}

module.exports = router