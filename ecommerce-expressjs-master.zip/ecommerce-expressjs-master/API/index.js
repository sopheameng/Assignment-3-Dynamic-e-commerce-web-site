const express = require('express')
const cors = require('cors');
const app = express()
const mongoose = require('mongoose')
app.use(cors());
app.options('*', cors());

// Databse
mongoose.connect('mongodb+srv://test:test@cluster0.n95ju.mongodb.net/Cluster0?retryWrites=true&w=majority', {useNewUrlParser: true});
const db = mongoose.connection
db.on('error', (error) => console.error(error))
db.once('open', () => console.log("Database is connected."))

app.use(express.json())

const productRouter = require('./routers/products')
const userRouter = require('./routers/users')
const commentRouter = require('./routers/comments')
app.use('/products', productRouter)
app.use('/comments', commentRouter)
app.use('/users', userRouter)


// port
const port = process.env.PORT || 3000
app.listen(port, () => {
    console.log(`Example app listening at http://localhost:${port}`)
})