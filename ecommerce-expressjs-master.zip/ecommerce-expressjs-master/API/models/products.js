const mongoose = require('mongoose');


const productSchema = mongoose.Schema({
    name: {
        type: String,
        required: true,
    },
    category: {
        type: String,
        required: true,
    }, 
    quantity: {
        type: Number,
        required: true,
    },
    price: {
        type: String,
        required: true
    }, 
    description: {
        type: String,
        required: true
    },
    discount: {
        type: Boolean,
        default: false,
    },
    discountPercent: {
        type: Number,
        default: 0,
    },
    postDate: {
        type: Date,
        required: true,
        default: Date.now
    }
})

module.exports = mongoose.model("productSchema", productSchema)