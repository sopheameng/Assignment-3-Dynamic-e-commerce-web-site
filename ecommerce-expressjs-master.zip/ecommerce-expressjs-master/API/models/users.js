const mongoose = require('mongoose');

const userSchema = mongoose.Schema({
    email: {
        type: String,
        required: true,
    },
    username: {
        type: String,
        required: true,
    },
    userType: {
        type: String,
        default: "normal",
    },
    password:  {
        type: String,
        required: true,
    },
    createDate: {
        type: Date,
        required: true,
        default: Date.now
    }
})

module.exports = mongoose.model("userSchema", userSchema)