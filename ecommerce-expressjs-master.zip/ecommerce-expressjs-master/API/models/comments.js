const mongoose = require('mongoose');


const commentSchema = mongoose.Schema({
    commentOwnerName: {
        type: String,
        required: true,
    },
    commentOwnerID: {
        type: String,
        required: true,
    },
    commentContent: {
        type: String,
        required: true,
    },
    productID: {
        type: String,
        required: true,
    }
})

module.exports = mongoose.model("commentSchema", commentSchema)